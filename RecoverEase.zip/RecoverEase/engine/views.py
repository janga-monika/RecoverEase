from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
from engine.models import Found, Lost
from django.contrib.auth.models import User
from django.contrib import messages
from DeepImageSearch import Index, LoadData, SearchImage
import os
import smtplib
from email.mime.text import MIMEText

email_sender = "mrcetlms@gmail.com"
email_password = "dnny kmek phsn trlj"


def send_email(subject, body, sender, recipients, password):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = ', '.join(recipients)
    smtp_server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    smtp_server.login(sender, password)
    smtp_server.sendmail(sender, recipients, msg.as_string())
    smtp_server.quit()


def emailLost(request, slug):
    obj = ""
    path = r"E:\Final project\RecoverEase\media"
    for i in Found.objects.all():
        if i.sno == slug:
            obj = i
    em = obj.email
    initial = User.objects.get(username=request.user)
    subject = "Re. Item Found"
    recipients = [em]
    res = [initial.email]

    message = f"Hello {obj.name}\nYour {obj.itemname}, which was uploaded as found by you belongs to {initial.first_name}\nHe will contact you shortly with his id {initial.email}"
    msg = f"Hello {initial.username}\nYour {obj.itemname}, which was uploaded as lost by you was found by {obj.name}\nPlease contact him on his email id: {em}"

    send_email(subject, message, email_sender, recipients, email_password)
    send_email(subject, msg, email_sender, res, email_password)

 
    fin = os.path.join(path, obj.image.name)
    os.remove(fin)

    obj.delete()

    messages.success(request, "Informed successfully")
    return redirect('home')


def emailf(request, slug):
    obj = ""
    path = r"E:\Final project\RecoverEase\media"
    for i in Lost.objects.all():
        if i.sno == slug:
            obj = i

    em = obj.email
    recipients = [em]
    subject = "Re. Item Found"

    initial = User.objects.get(username=request.user)

    for i in Found.objects.all():
        if i.sno == slug:
            obj = i
    em = obj.email

    message = f"Hello {obj.name}\nYour {obj.itemname}, which was uploaded as lost by you was found by {initial.username}\nPlease contact him/her through email id: {initial.email}"

    send_email(subject, message, email_sender, recipients, email_password)

    fin = os.path.join(path, obj.image.name)
    os.remove(fin)
    obj.delete()

    messages.success(request, "Informed successfully")
    return redirect('home')


def find(category, image):
    if category == "Found":
        path = r"E:\Final project\RecoverEase\media\images\Found"

        image_list = LoadData().from_folder(folder_list=[path])

        Index(image_list).Start()
        return SearchImage().get_similar_images(image_path=image, number_of_images=1)
    else:
        path = r"E:\Final project\RecoverEase\media\images\Lost"

        image_list = LoadData().from_folder(folder_list=[path])

        Index(image_list).Start()
        return SearchImage().get_similar_images(image_path=image, number_of_images=1)


params = User.objects.all()


def root(request):
    print(User.objects.get(username=request.user).first_name)
    return HttpResponse("Checking 101")


def force(request):
    if request.method == "POST":
        item = request.POST['ite']
        name = ""
        email = request.POST['emal']
        image = request.FILES['img']
        for i in params:
            if i.email == email:
                name = i.username

        Eng = Lost(itemname=item, name=name, image=image, email=email)
        Eng.save()

        messages.success(request, "Your item has been uploaded in the database")

        return redirect('home')
    else:
        return HttpResponse("Checking")


def forceadd(request):
    if request.method == "POST":
        item = request.POST['item']
        name = ""
        email = request.POST['email']
        image = request.FILES['image']
        for i in params:
            if i.email == email:
                name = i.username

        Eng = Found(itemname=item, name=name, image=image, email=email)
        Eng.save()

        messages.success(request, "Your item has been uploaded in the database")

        return redirect('home')
    else:
        return HttpResponse("Checking")


def add(request):
    if request.method == "POST":
        item = request.POST['item']
        name = ""
        email = request.POST['email']
        image = request.FILES['image']
        dic = find("Lost", image)
        if len(dic) == 'None':
            for i in params:
                if i.email == email:
                    name = i.username

            Eng = Found(itemname=item, name=name, image=image, email=email)
            Eng.save()

            messages.success(request, "Your item has been uploaded in the database")

            return redirect('home')
        else:
            path = """images/Lost/""" + list(dic.values())[0].split('\\')[-1]

            parameters = {}
            for i in Lost.objects.all():
                if i.image == path:
                    parameters['p1'] = i
                    break;
            if len(parameters) == 0:
                Eng = Found(itemname=item, name=name, image=image, email=email)
                Eng.save()

                messages.success(request, "Your item has been uploaded in the database")

                return redirect('home')

            return render(request, "engine/found.html", parameters)


def search(request):
    if request.method == "POST":
        item = request.POST['ite']
        name = ""
        email = request.POST['emal']
        image = request.FILES['img']
        dic = find("Found", image)

        if len(dic) == 0:
            for i in params:
                if i.email == email:
                    name = i.username

            Eng = Lost(itemname=item, name=name, image=image, email=email)
            Eng.save()

            messages.success(request, "Your item has been uploaded in the database")

            return redirect('home')
        else:
            path = """images/Found/""" + list(dic.values())[0].split('\\')[-1]

            parameters = {}
            for i in Found.objects.all():
                if i.image == path:
                    parameters['p1'] = i
                    break;
            if len(parameters) == 0:
                Eng = Lost(itemname=item, name=name, image=image, email=email)
                Eng.save()

                messages.success(request, "Your item has been uploaded in the database")

                return redirect('home')

            return render(request, "engine/lost.html", parameters)


def delete_lost_item(request, item_id):
    item = get_object_or_404(Lost, pk=item_id)
    if request.method == 'POST':
        item.delete()
    return redirect('history')  


def delete_found_item(request, item_id):
    item = get_object_or_404(Found, pk=item_id)
    if request.method == 'POST':
        item.delete()
    return redirect('history')  
