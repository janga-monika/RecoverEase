from django.contrib import admin
from django.urls import path,include
from home import views

urlpatterns = [
    
    
    path('', views.home,name="home"),
    
    # path('contact/', views.contact,name="contact"),
    path('about/', views.about,name="about"),
    path('signup/', views.handleSignUp,name="signup"),
    path('login/', views.handleLogin,name="login"),
    path('logout/', views.handleLogout,name="logout"),
    path('history/', views.history, name='history'),
    path('all/', views.all, name='all'),

    path('delete_lost_item/<int:item_id>/', views.delete_lost_item, name='delete_lost_item'),
    path('delete_found_item/<int:item_id>/', views.delete_found_item, name='delete_found_item'),    
    # new here
    # path('upload/', views.upload,name="upload"),
    
]